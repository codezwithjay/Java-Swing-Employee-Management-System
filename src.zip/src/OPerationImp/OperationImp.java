package OPerationImp;
import OPeration.Operations;
public class OperationImp implements  Operations{

	@Override
	public void insertdata() {
	
		
	}

	@Override
	public void updatdata() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deletedata() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void showdata() {
		// TODO Auto-generated method stub
		
	}

}
