package Home;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.swing.*;

import Delete.Delete;
import Delete.DeleteManager;
import Delete.DeleteStaff;
import GetConnection.GetCon;
import Insert.Insert;
import Insert.InsertManager;
import Insert.InsertStaff;
import Show.Show;
import Show.ShowManager;
import Show.ShowStaff;
import UI.POJO;
import update.Update;
import update.UpdateManager;
import update.UpdateStaff;

public class Home extends JFrame {
    JMenuBar bar;
    JMenu jMenu, jMenu2, jMenu3;
    JMenuItem item, item2, item3, item4, item5, item6,item7,item8,item9,item10, item11,item12;

    public Home() {
    	setLayout(new FlowLayout());
        // Create the menu bar
        bar = new JMenuBar();

        // Create menus
        jMenu = new JMenu("Employee");
        jMenu2 = new JMenu("Manager");
        jMenu3 = new JMenu("Staff");

        // Create menu items
        item = new JMenuItem("Insert");   //Employees
        item2 = new JMenuItem("Update");
        item3 = new JMenuItem("Delete");
        item4 = new JMenuItem("Show");
        
        item5 = new JMenuItem("Insert");//Manager
        item7=new JMenuItem("Update");
        item8=new JMenuItem("Delete");
        item9=new JMenuItem("Show");
        
        item6 = new JMenuItem("Insert");//Staff
        item10=new JMenuItem("Update");
        item11=new JMenuItem("Delete");
        item12=new JMenuItem("Show");
        
        jMenu.add(item);
        jMenu.add(item2);
        jMenu.add(item3);
        jMenu.add(item4);
        
        jMenu2.add(item5);
        jMenu2.add(item7);
        jMenu2.add(item8);
        jMenu2.add(item9);
        
        
        jMenu3.add(item6);
        jMenu3.add(item10);
        jMenu3.add(item11);
        jMenu3.add(item12);
        
        bar.add(jMenu);
        bar.add(jMenu2);
        bar.add(jMenu3);
        add(bar);
        
       item12.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
		        new ShowStaff();		
			}
		});
        
        
        item9.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
		        new ShowManager();		
			}
		});
        
        
        item11.addActionListener(new ActionListener() {
			
   			@Override
   			public void actionPerformed(ActionEvent e) {
   		     new DeleteStaff();		
   			}
   		});
        
        
        item8.addActionListener(new ActionListener() {
			
   			@Override
   			public void actionPerformed(ActionEvent e) {
   		     new DeleteManager();		
   			}
   		});
        
        item10.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
		
				new UpdateStaff();
				
				
			}
		});
        
        
        item7.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
		
				new UpdateManager();
				
				
			}
		});
        
        
        item6.addActionListener(new ActionListener() {
     			POJO Home=new POJO();
     			@Override
     			public void actionPerformed(ActionEvent e) {
     		
     				PreparedStatement preparedStatement;
     				try {
     					preparedStatement = GetCon.getConnection().prepareStatement("insert into info values(?,?)");
     					//preparedStatement.setString(1,Home.getName());
     					//preparedStatement.setString(2,Home.getId());
     					//preparedStatement.executeUpdate();
     					new InsertStaff();
     					
     					System.out.println("inserted bro");
     				} catch (SQLException e1) {
     					// TODO Auto-generated catch block
     					e1.printStackTrace();
     				}
     				
     				
     			}
     		});
         
        
        item5.addActionListener(new ActionListener() {
    			POJO Home=new POJO();
    			@Override
    			public void actionPerformed(ActionEvent e) {
    		
    				PreparedStatement preparedStatement;
    				try {
    					preparedStatement = GetCon.getConnection().prepareStatement("insert into info values(?,?)");
    					//preparedStatement.setString(1,Home.getName());
    					//preparedStatement.setString(2,Home.getId());
    					//preparedStatement.executeUpdate();
    					new InsertManager();
    					
    					System.out.println("inserted bro");
    				} catch (SQLException e1) {
    					// TODO Auto-generated catch block
    					e1.printStackTrace();
    				}
    				
    				
    			}
    		});
        
        item4.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
		
			new Show();
			
			}
		});
        item3.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
		     new Delete();		
			}
		});
        item2.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
		
				new Update();
				
				
			}
		});
        item.addActionListener(new ActionListener() {
			POJO Home=new POJO();
			@Override
			public void actionPerformed(ActionEvent e) {
		
				PreparedStatement preparedStatement;
				try {
					preparedStatement = GetCon.getConnection().prepareStatement("insert into info values(?,?)");
					//preparedStatement.setString(1,Home.getName());
					//preparedStatement.setString(2,Home.getId());
					//preparedStatement.executeUpdate();
					new Insert();
					
					System.out.println("inserted bro");
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				
			}
		});
        setSize(400, 400);
       
        setVisible(true);
    }

    public static void main(String[] args) {
        new Home();
    }
}
