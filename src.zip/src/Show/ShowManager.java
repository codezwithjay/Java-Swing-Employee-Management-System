package Show;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;

import GetConnection.GetCon;

public class ShowManager extends JFrame {

    public ShowManager() {
        // Setup layout and components
        setLayout(new FlowLayout());

        JLabel jLabel = new JLabel("Manager Data:");
        JTextArea textArea = new JTextArea(20, 30);  // Text area to show data (20 rows, 30 columns)
        textArea.setEditable(false);  // Make text area read-only

        JScrollPane scrollPane = new JScrollPane(textArea); // Add text area to scroll pane

        JButton button = new JButton("Show All Data");

        // Add components to frame
        add(jLabel);
        add(scrollPane);  // <-- Important: add the scroll pane, not just the text area
        add(button);

        // Button action listener to fetch data and display it
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    PreparedStatement preparedStatement = GetCon.getConnection().prepareStatement("SELECT * FROM info");
                    ResultSet resultSet = preparedStatement.executeQuery();

                    // Clear the text area before showing new data
                    textArea.setText("");

                    while (resultSet.next()) {
                        String name = resultSet.getString("name");  // Replace with actual column name
                        String id = resultSet.getString("id");      // Replace with actual column name

                        textArea.append("ID: " + id + ", Name: " + name + "\n");
                    }

                    System.out.println("Data shown successfully!");

                } catch (SQLException ex) {
                    ex.printStackTrace();
                    textArea.setText("Error fetching data from database.");
                }
            }
        });

        // Frame settings
        setTitle("Employee Viewer");
        setSize(400, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    public static void main(String[] args) {
        new ShowManager();
    }
}
